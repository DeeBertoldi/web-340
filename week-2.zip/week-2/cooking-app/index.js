/**
 * Author:
 * Date:
 * File Name:
 * Description:
 */

"use strict";

// TODO: Import your module using require
const { createRecipe, setTimer, quit } = require("./recipes");

console.log(createRecipe(["flour", "sugar", "eggs"]));
console.log(setTimer(30));
console.log(quit());

// TODO: Implement your CLI program here
